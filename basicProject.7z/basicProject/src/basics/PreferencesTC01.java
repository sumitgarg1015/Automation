package basics;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import static basics.DriverEngine.initDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class PreferencesTC01 {
	
	private static WebElement el;
	public static AndroidDriver<AndroidElement> driver;
	
	
	@BeforeSuite
	public void startDriver() throws IOException {
		
		driver = initDriver();
	}
	
	
	@Test(enabled = false) 
	public void DefaultPreference(){
		
		
		driver.findElementByXPath("//android.widget.TextView[@text='Preference']").click();
		TapAction.tapelement(driver.findElementsById("android:id/text1").get(3));
		TapAction.tapelement(driver.findElementByClassName("android.widget.CheckBox"));
		
	}
	
	
	@Test
	public void swipeClock() {
		
		
		
	}
	
	@AfterSuite
	public void closeDriver() {
		
		driver.close();
		driver.quit();
		
	}

}