package basics;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import static basics.DriverEngine.initDriver;

import io.appium.java_client.FindsByAndroidUIAutomator;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class PreferencesTC01 {
	
	private static WebElement el, minfirst, minsec;
	public static AndroidDriver<AndroidElement> driver;
	
	
	@BeforeSuite
	public void startDriver() throws IOException {
		
		driver = initDriver();
	}
	
	
	@Test(enabled = false) 
	public void DefaultPreference(){
		
		
		driver.findElementByXPath("//android.widget.TextView[@text='Preference']").click();
		TapAction.tapelement(driver.findElementsById("android:id/text1").get(3));
		TapAction.tapelement(driver.findElementByClassName("android.widget.CheckBox"));
		
	}
	
	
	@Test
	public void swipeClock() {
		
		el = ((FindsByAndroidUIAutomator) driver).findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0))"
				+ ".scrollIntoView(new UiSelector().text(\"Views\").instance(0);");
		TapAction.tapelement(el);
		TapAction.tapelement(driver.findElement(By.xpath("//*[@content-desc = 'Date Widgets']")));
		TapAction.tapelement(((FindsByAndroidUIAutomator) driver).findElementByAndroidUIAutomator("new UiSelector().text(\"2. Inline\")"));
		TapAction.tapelement(driver.findElementByXPath("//*[@content-desc='6']"));
		minfirst = driver.findElementByXPath("//*[@content-desc='25']");
		minsec = driver.findElementByXPath("//*[@content-desc='55']");
		
		TapAction.swipescreen(minfirst, minsec);
		
//		TapAction.tapelement(driver.findElementByXPath("//*[@text='Graphics']"));
		
	}
	
	@AfterSuite
	public void closeDriver() {
		
		driver.close();
		driver.quit();
		
	}

}