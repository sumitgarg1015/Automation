package basics;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class DriverEngine {

	public static AndroidDriver<AndroidElement> initDriver() throws IOException {
		
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Nexus5_Android8");
		cap.setCapability(MobileCapabilityType.AUTOMATION_NAME, "espresso");
//		cap.setCapability(MobileCapabilityType.ACCEPT_INSECURE_CERTS, true);
		
		File file = new File("src");
		File appFile = new File(file, "ApiDemos-debug.apk");
		
		cap.setCapability(MobileCapabilityType.APP, appFile.getAbsolutePath());
		
		AndroidDriver<AndroidElement> ad = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), cap);
		
		ad.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		return ad;
	}

}
