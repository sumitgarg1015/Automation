package basics;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static java.time.Duration.ofSeconds;

import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import org.openqa.selenium.WebElement;
import static basics.PreferencesTC01.driver;

import io.appium.java_client.TouchAction;

public class TapAction {
	
	private static TouchAction touch;
	public static void tapelement(WebElement el){
		
		touch = new TouchAction (driver);
		touch.tap(tapOptions().withElement(element(el))).perform();
		
	}
	
	public static void swipescreen(WebElement first, WebElement sec) {
		
		touch = new TouchAction (driver);
		touch.longPress(longPressOptions().withElement(element(first)).withDuration(ofSeconds(2)))
				.moveTo(element(sec)).release().perform();
		
	}

}
