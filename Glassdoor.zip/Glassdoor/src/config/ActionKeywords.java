package config;

import org.openqa.selenium.By;
import static driverEngine.driverScript.driver;
public class ActionKeywords {
	
	public static void input() {
		
		driver.findElement(By.xpath("//li[@data-search-type='EMPLOYER' and @tabindex='2']/span")).click();
		
	}

}
