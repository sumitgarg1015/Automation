package  config;

public interface Constants {
	
	public static final String appUrl = "https://www.glassdoor.co.in";
	public static final String chromeDriver = "C:\\Selenium_Workspace\\Jars\\chromedriver.exe";
	public static final String or_Path = System.getProperty("user.dir") + "\\src\\config\\" + "OR.Properties";

}
