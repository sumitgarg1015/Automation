package checkTest;

import org.testng.annotations.Test;

public class validateFunc {
	
	@Test
	public void checkResult() {
		
		String or_Path = System.getProperty("user.dir") + "\\src\\config\\" + "OR.Properties";
		System.out.println(or_Path);
	}

}
