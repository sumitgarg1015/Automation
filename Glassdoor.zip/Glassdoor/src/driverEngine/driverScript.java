package driverEngine;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import config.Constants;

public class driverScript {
	
	public static WebDriver driver;
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", Constants.chromeDriver);
		driver = new ChromeDriver();
		driver.get(Constants.appUrl);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		
		driver.findElement(By.xpath("//input[@id='KeywordSearch']")).sendKeys("Kronos");
		driver.findElement(By.xpath("//button[@id='HeroSearchButton']")).submit();
		try {
			if(driver.findElement(By.linkText(" Kronos Incorporated ")).isDisplayed()){
				String rating = driver.findElement(By.xpath("//a[contains(text(),' Kronos Incorporated ')]/ancestor::div[contains(@class,'empInfo')]/following-sibling::div[contains(@class,'empLinks')]//span[contains(@class,'bigRating')]")).getText();
				System.out.println(rating);
			}
		}catch(Exception e) {
			System.out.println(e.toString());
		}finally {
			driver.quit();
		}
		
	}

}
