package testFunc;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.Test;


public class SearchOps {
	public static WebDriver driver; 
	@Test
	public void checkIf(){
		
		driver = new ChromeDriver();
		

	}


}
