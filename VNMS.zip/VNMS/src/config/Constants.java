package config;

public interface Constants {
	
	public static final String chromeDriverProperty = "webdriver.chrome.driver";
	public static final String IEDriverProperty = "webdriver.ie.driver";
	public static final String chromeDriverPath = "C://Selenium_Workspace//Jars//chromedriver.exe";
	public static final String IEDriverPath = "C://Selenium_Workspace//Jars//IEDriverServer.exe";
	public static final String screenShotPath = "C://Selenium_Workspace//Google_Accounts//screen//";
	public static final String htmlReport = "C://Selenium_Workspace//Google_Accounts//report.html";
	
	public static final String url = "http://vnweb.westeurope.cloudapp.azure.com";
	
	public static final String filePath = "C://Selenium_Workspace//Google_Accounts//src//dataEngine//dataEngine.xlsx";
	public static final String uploadPath = "E://RMG//Test.jpg";
	public static final String sheet_TestSteps = "TestSteps";
	public static final String sheet_TestCases = "TestCases";

	public static final String recodedScript = "C://Selenium_Workspace//VNMS//src//vnms.exe";
	public static final int col_testCaseID = 0;
	public static final int col_testScenario = 1;
	public static final int col_runMode = 2;
	public static final int col_Keywords = 6;
	public static final int col_pageObject = 5;
	
	public static final int col_tcResult = 3;
	public static final int col_tsStatus = 8;
	public static final int col_tsValue = 7;
	
	public static final String OR_Path = "C://Selenium_Workspace//Google_Accounts//src//config//OR";
	
	public static final String status_Fail = "Fail";
	public static final String status_Pass = "Pass";
	

}
